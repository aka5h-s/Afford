package com.hexaware.ams.controller;

import com.hexaware.ams.dto.ServiceRequestCreateDto;
import com.hexaware.ams.dto.ServiceRequestUpdateDto;
import com.hexaware.ams.entity.ServiceRequest;
import com.hexaware.ams.service.IServiceRequestService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
// import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/ams/servicerequest")
public class ServiceRequestController {

    @Autowired
    private IServiceRequestService serviceRequestService;

    @PostMapping("/createServiceRequest")
     @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    public ResponseEntity<ServiceRequest> createServiceRequest(
            @Valid @RequestBody ServiceRequestCreateDto dto) {

        ServiceRequest newServiceRequest = serviceRequestService.createServiceRequest(
                dto.getEmployeeId(),
                dto.getAssetId(),
                dto.getIssueTypeId(),
                dto.getDescription()
        );
        return new ResponseEntity<>(newServiceRequest, HttpStatus.CREATED);
    }

    // Get Service Request By its Id
    @GetMapping("/getServiceRequestById/{serviceRequestId}")
     @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ServiceRequest> getServiceRequestById(@PathVariable int serviceRequestId) {
        ServiceRequest serviceRequest = serviceRequestService.getServiceRequestById(serviceRequestId);
        return ResponseEntity.ok(serviceRequest);
    }

    // ✅ Update a Service Request By JSON body
    @PutMapping("/updateServiceRequest")
     @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ServiceRequest> updateServiceRequest(
            @Valid @RequestBody ServiceRequestUpdateDto dto) {

        ServiceRequest updatedServiceRequest = serviceRequestService.updateServiceRequestStatus(
                dto.getServiceRequestId(),
                dto.getStatus()
        );
        return ResponseEntity.ok(updatedServiceRequest);
    }

    // Get service Requests By Employee Id 
    @GetMapping("/serviceRequestByEmployee/{employeeId}")
     @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    public ResponseEntity<List<ServiceRequest>> getServiceRequestsByEmployee(@PathVariable int employeeId) {
        List<ServiceRequest> employeeServiceRequests = serviceRequestService.getServiceRequestsByEmployee(employeeId);
        return ResponseEntity.ok(employeeServiceRequests);
    }

    // Get all service Requests 
    @GetMapping("/allServiceRequests")
     @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<ServiceRequest>> getAllServiceRequests() {
        List<ServiceRequest> serviceRequests = serviceRequestService.getAllServiceRequests();
        return ResponseEntity.ok(serviceRequests);
    }

    // Find Service Requests by Status
    @GetMapping("/findByStatus/{status}")
     @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<ServiceRequest>> findByStatus(@PathVariable ServiceRequest.Status status) {
        List<ServiceRequest> serviceRequestByStatus = serviceRequestService.findByStatus(status);
        return ResponseEntity.ok(serviceRequestByStatus);
    }
}
