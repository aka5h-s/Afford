package com.hexaware.ams.controller;

import com.hexaware.ams.dto.BorrowRequestDto;
import com.hexaware.ams.dto.ReturnRequestDto;
import com.hexaware.ams.entity.AssetBorrowing;
import com.hexaware.ams.service.IAssetBorrowingService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/borrowings")
public class AssetBorrowingController {

    @Autowired
    private IAssetBorrowingService assetBorrowingService;

    @PostMapping("/borrow")
     @PreAuthorize("hasAnyRole('ADMIN','USER')") 
    public ResponseEntity<AssetBorrowing> borrowAsset(@Valid @RequestBody BorrowRequestDto dto) {
        AssetBorrowing borrowing = assetBorrowingService.borrowAsset(dto.getEmployeeId(), dto.getAssetId());
        return ResponseEntity.ok(borrowing);
    }

    @PutMapping("/return")
     @PreAuthorize("hasAnyRole('ADMIN','USER')")
    public ResponseEntity<AssetBorrowing> returnAsset(@Valid @RequestBody ReturnRequestDto dto) {
        AssetBorrowing borrowing = assetBorrowingService.returnAsset(dto.getBorrowingId());
        return ResponseEntity.ok(borrowing);
    }

    @GetMapping("/getbyeid/{employeeId}")
     @PreAuthorize("hasAnyRole('ADMIN','USER')")
    public ResponseEntity<List<AssetBorrowing>> getBorrowingsByEmployee(@PathVariable int employeeId) {
        List<AssetBorrowing> borrowings = assetBorrowingService.getBorrowingsByEmployee(employeeId);
        return ResponseEntity.ok(borrowings);
    }

    @GetMapping("/active")
     @PreAuthorize("hasRole('ADMIN')") 
    public ResponseEntity<List<AssetBorrowing>> getAllActiveBorrowings() {
        List<AssetBorrowing> activeBorrowings = assetBorrowingService.getAllActiveBorrowings();
        return ResponseEntity.ok(activeBorrowings);
    }
}
