package com.hexaware.ams.dto;


import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AssetAuditDto {

    public enum AuditStatus {
        Pending,
        Verified,
        Rejected
    }

    @NotNull(message = "Audit ID is required")
    private Integer auditId;

    @NotNull(message = "Employee details are required")
    private EmployeeDto employeeDto;

    @NotNull(message = "Asset details are required")
    private AssetDto assetDto;

    @NotNull(message = "Audit status is required")
    private AuditStatus auditStatus = AuditStatus.Pending;

    @NotNull(message = "Requested date/time is required")
    @PastOrPresent(message = "Requested date/time must be in the past or present")
    private LocalDateTime requestedAt;

    @PastOrPresent(message = "Updated date/time must be in the past or present")
    private LocalDateTime updatedAt;
}
