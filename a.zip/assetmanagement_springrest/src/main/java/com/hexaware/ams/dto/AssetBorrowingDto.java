package com.hexaware.ams.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AssetBorrowingDto {

    public enum Status {
        Active,
        Returned
    }

    @NotNull(message = "Borrowing ID is required")
    private Integer borrowingId;

    @NotNull(message = "Employee details are required")
    private EmployeeDto employeeDto;

    @NotNull(message = "Asset details are required")
    private AssetDto assetDto;

    @NotNull(message = "Borrowed date/time is required")
    @PastOrPresent(message = "Borrowed date/time must be in the past or present")
    private LocalDateTime borrowedAt;

    @Future(message = "Return date/time must be in the future")
    private LocalDateTime returnedAt;

    @NotNull(message = "Borrowing status is required")
    private Status status = Status.Active;
}
