package com.hexaware.ams.dto;



import java.time.LocalDateTime;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ServiceRequestDto {

    @Min(value = 1, message = "Service request ID must be at least 1")
    private int serviceRequestId;

    @NotNull(message = "Employee is required")
    @Valid
    private EmployeeDto employee;

    @NotNull(message = "Asset is required")
    @Valid
    private AssetDto asset;

    @NotBlank(message = "Description is required")
    @Size(max = 500, message = "Description must not exceed 500 characters")
    private String description;

    @NotNull(message = "Issue type is required")
    @Valid
    private IssueTypeDto issueType;

    @NotNull(message = "Status is required")
    private StatusDTO status = StatusDTO.Pending;

    @NotNull(message = "Requested time is required")
    @PastOrPresent(message = "Requested time must be in the past or present")
    private LocalDateTime requestedAt;

    public enum StatusDTO {
        Pending, Transit, Completed
    }
}
