// src/main/java/com/hexaware/ams/dto/ServiceRequestUpdateDto.java
package com.hexaware.ams.dto;

import com.hexaware.ams.entity.ServiceRequest;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ServiceRequestUpdateDto {
    @NotNull @Min(1)
    private Integer serviceRequestId;

    @NotNull
    private ServiceRequest.Status status;
}
