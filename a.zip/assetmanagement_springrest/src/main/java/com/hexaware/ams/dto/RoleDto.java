package com.hexaware.ams.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoleDto {

    @NotNull(message = "Role ID is required")
    private Integer roleId;

    @NotBlank(message = "Role name is required")
    @Size(max = 30, message = "Role name must not exceed 30 characters")
    private String roleName; // ✅ Will generate getRoleName()/setRoleName()
}
